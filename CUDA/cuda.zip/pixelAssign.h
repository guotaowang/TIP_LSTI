// pixelAssign.h
#ifndef __PIXELASSIGN_H__
#define __PIXELASSIGN_H__
extern void pixelAssign(double * result, const double * input1, const double * input2, double * localSize,double *Par);
#endif//__PIXELASSIGN_H__